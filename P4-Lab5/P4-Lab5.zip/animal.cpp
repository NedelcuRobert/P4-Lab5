#include "animal.h"

void CAnimal::set_animal(string n,int zi,int luna,int an,float g,string h,float c) {
	nume = n;
	data[0] = zi;
	data[1] = luna;
	data[2] = an;
	greutate = g;
	hrana = h;
	cantitate_hrana = c;
}

void CAnimal::afisare_animal() {
	cout << "Nume:" << " " << nume << endl;
	cout << "Data:" << " " << data[0] << " " << data[1] << " " << data[2] << endl;
	cout << "Greutate:" << " " << greutate << endl;
	cout << "Hrana:" << " " << hrana << endl;
	cout << "Cantitate hrana:" << " " << cantitate_hrana << endl;
}