#include <iostream>
#include <string>

using namespace std;

class CAnimal
{
protected:
	string nume;
	int data[3];
	float greutate;
	string hrana;
	float cantitate_hrana;
public:
	void set_animal(string n, int zi, int luna, int an, float g, string h, float c);
	void afisare_animal();
};

