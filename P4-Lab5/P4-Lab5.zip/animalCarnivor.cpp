#include "animalCarnivor.h"

void CAnimalCarnivor::set_animal_carnivor(string n, int zi, int luna, int an, float g, string h, float c) {
	set_animal(n, zi, luna, an, g, h, c);
	fel = "Carnivor";
}

void CAnimalCarnivor::afisare_animal_carnivor() {
	afisare_animal();
	cout << fel << endl;
}
