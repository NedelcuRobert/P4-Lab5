#include "animalIerbivor.h"

class CAnimalCarnivor:public CAnimal
{
protected:
	string fel;
public:
	void set_animal_carnivor(string n, int zi, int luna, int an, float g, string h, float c);
	void afisare_animal_carnivor();
};

