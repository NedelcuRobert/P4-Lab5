#include "animalIerbivor.h"

void CAnimalIerbivor::set_animal_ierbivor(string n, int zi, int luna, int an, float g, string h, float c) {
	set_animal(n, zi, luna, an, g, h, c);
	fel = "Ierbivor";
}
void CAnimalIerbivor::afisare_animal_ierbivor() {
	afisare_animal();
	cout << fel << endl;
}
