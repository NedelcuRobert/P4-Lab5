#include "caprioara.h"

void CCaprioara::set_caprioara(string n, int zi, int luna, int an, float g, string h, float c, int nr) {
	set_animal_ierbivor(n, zi, luna, an, g, h, c);
	nr_pui = nr;
}

void CCaprioara::afisare_caprioara() {
	afisare_animal_ierbivor();
	cout << "Numar pui:" << " " << nr_pui << endl;
}