#include "urs.h"

class CCaprioara:public CAnimalIerbivor
{
protected:
	int nr_pui;
public:
	void set_caprioara(string n, int zi, int luna, int an, float g, string h, float c, int nr);
	void afisare_caprioara();
};

