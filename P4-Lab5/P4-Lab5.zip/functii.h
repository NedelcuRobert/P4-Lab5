#include <iostream>
#include <string>
#include <stdlib.h>
#include <time.h>

using namespace std;

string random_string(int t);

int random_zi(int t);

int random_luna(int t);

int random_an(int t);

float random_greutate(int t);

int random_nr_int(int t);

float random_nr_float(int t);

string random_tip_vulpe(int t);
