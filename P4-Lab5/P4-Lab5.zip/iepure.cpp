#include "iepure.h"

void CIepure::set_iepure(string n, int zi, int luna, int an, float g, string h, float c, int s) {
	set_animal_ierbivor(n, zi, luna, an, g, h, c);
	suprafata_min = s;
}
void CIepure::afisare_iepure() {
	afisare_animal_ierbivor();
	cout << "Suprafata minima:" << " " << suprafata_min << endl;
}
