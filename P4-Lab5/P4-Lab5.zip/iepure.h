#include "animalCarnivor.h"

class CIepure:public CAnimalIerbivor
{
protected:
	int suprafata_min;
public:
	void set_iepure(string n, int zi, int luna, int an, float g, string h, float c,int s);
	void afisare_iepure();
};

