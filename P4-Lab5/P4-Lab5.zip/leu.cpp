#include "leu.h"

void CLeu::set_leu(string n, int zi, int luna, int an, float g, string h, float c,float t,string ta) {
	set_animal_carnivor(n, zi, luna, an, g, h, c);
	temp_min = t;
	tara_prov = ta;
}

void CLeu::afisare_leu() {
	afisare_animal_carnivor();
	cout << "Temperatura minima:" << " " << temp_min << endl;
	cout << "Tara de provenienta:" << " " << tara_prov << endl;
}
