#include "vulpe.h"

class CLeu:public CAnimalCarnivor
{
protected:
	float temp_min;
	string tara_prov;
public:
	void set_leu(string n, int zi, int luna, int an, float g, string h, float c,float t,string ta);
	void afisare_leu();
};

