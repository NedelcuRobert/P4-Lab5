#include "rezervatie.h"
#include "functii.h"

void CRezervatie::initializare_animale() {
	for (int i = 0;i < dim_iepuri;i++) {
		iepuri[i].set_iepure(random_string(i), random_zi(i), random_luna(i), random_an(i), random_greutate(i+15), random_string(i + 56), random_nr_float(i), random_nr_int(i + 1));
	}
	for (int i = 0;i < dim_vulpi;i++) {
		vulpi[i].set_vulpe(random_string(i+1), random_zi(i+1), random_luna(i+1), random_an(i+1), random_greutate(i+67), random_string(i + 207), random_nr_float(i+1), random_nr_float(i+2), random_tip_vulpe(i+102));
	}
	for (int i = 0;i < dim_lei;i++) {
		lei[i].set_leu(random_string(i + 5), random_zi(i + 5), random_luna(i + 5), random_an(i + 5), random_greutate(i + 98), random_string(i + 7), random_nr_float(i + 8), random_nr_float(i + 4), random_string(i + 106));
	}
	for (int i = 0;i < dim_ursi;i++) {
		ursi[i].set_urs(random_string(i + 127), random_zi(i + 12), random_luna(i + 12), random_an(i + 12), random_greutate(i + 12), random_string(i + 131), random_nr_float(i + 20), random_nr_int(i + 30));
	}
	for (int i = 0;i < dim_caprioare;i++) {
		caprioare[i].set_caprioara(random_string(i + 35), random_zi(i + 35), random_luna(i + 35), random_an(i + 35), random_greutate(i + 35), random_string(i + 36), random_nr_float(i + 40), random_nr_int(i + 50));
	}
}

void CRezervatie::afisare_animale() {
	cout << "\nIepuri:\n" << endl;
	for (int i = 0;i < dim_iepuri;i++) {
		cout << "\nIepure " << i+1 << endl;
		iepuri[i].afisare_iepure();
	}
	cout << "\nVulpi:\n" << endl;
	for (int i = 0;i < dim_vulpi;i++) {
		cout << "\nVulpea " << i+1 << endl;
		vulpi[i].afisare_vulpe();
	}
	cout << "\nLei:\n" << endl;
	for (int i = 0;i < dim_lei;i++) {
		cout << "\nLeul " << i+1 << endl;
		lei[i].afisare_leu();
	}
	cout << "\nUrsi:\n" << endl;
	for (int i = 0;i < dim_lei;i++) {
		cout << "\nUrsul " << i+1 << endl;
		ursi[i].afisare_urs();
	}
	cout << "\nCaprioare:\n" << endl;
	for (int i = 0;i < dim_caprioare;i++) {
		cout << "\nCaprioara " << i+1 << endl;
		caprioare[i].afisare_caprioara();
	}
}
