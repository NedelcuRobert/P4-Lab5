#include "urs.h"

void CUrs::set_urs(string n, int zi, int luna, int an, float g, string h, float c, int pe) {
	set_animal_carnivor(n, zi, luna, an, g, h, c);
	set_animal_ierbivor(n, zi, luna, an, g, h, c);
	per_hibernare = pe;
}
void CUrs::afisare_urs() {
	afisare_animal_ierbivor();
	afisare_animal_carnivor();
	cout << "Perioada hibernare:" << " " << per_hibernare << endl;
}
