#include "leu.h"

class CUrs:public CAnimalCarnivor,public CAnimalIerbivor
{
protected:
	int per_hibernare;
public:
	void set_urs(string n, int zi, int luna, int an, float g, string h, float c, int pe);
	void afisare_urs();
};

