#include "vulpe.h"

void CVulpe::set_vulpe(string n, int zi, int luna, int an, float g, string h, float c, float t, string ti) {
	set_animal_ierbivor(n, zi, luna, an, g, h, c);
	set_animal_carnivor(n, zi, luna, an, g, h, c);
	temp_max = t;
	tip = ti;
}

void CVulpe::afisare_vulpe() {
	afisare_animal_ierbivor();
	afisare_animal_carnivor();
	cout << "Temperatura maxima:" << " " << temp_max << endl;
	cout << "Tip:" << " " << tip << endl;
}