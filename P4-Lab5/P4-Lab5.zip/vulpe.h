#include "iepure.h"

class CVulpe:public CAnimalIerbivor,public CAnimalCarnivor
{
protected:
	float temp_max;
	string tip;
public:
	void set_vulpe(string n, int zi, int luna, int an, float g, string h, float c, float t, string ti);
	void afisare_vulpe();
};

