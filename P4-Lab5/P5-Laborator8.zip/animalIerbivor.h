#include "animal.h"

class CAnimalIerbivor:public CAnimal
{
public:
	void citire_animal(int timp);
	void afisare_animal();
};

