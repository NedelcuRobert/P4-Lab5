#include "animalCarnivor.h"

class CIepure:public CAnimalIerbivor
{
private:
	int suprafata_min;
public:
	void citire_animal(int timp);
	void afisare_animal();
};

