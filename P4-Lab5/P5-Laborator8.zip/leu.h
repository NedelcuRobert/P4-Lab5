#include "vulpe.h"

class CLeu:public CAnimalCarnivor
{
private:
	float temp_min;
	string tara_prov;
public:
	void citire_animal(int timp);
	void afisare_animal();
};

