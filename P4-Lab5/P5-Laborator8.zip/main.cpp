#include "rezervatie.h"

int main() {

	CRezervatie rezervatie;

	rezervatie.initializare_animale();

	rezervatie.afisare_animale();

	return 0;
}